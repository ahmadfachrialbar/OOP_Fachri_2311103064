/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop_2311103064_ahmad.fachri.albar;

/**
 *
 * @author Ahmad Fachri Albar_2311103064_SI07B
 */
public class KomputerVIP extends Komputer {
    protected boolean vipCard;
    public KomputerVIP(int jumlahKomputer, String namaWarnet, float hargaPerJam, boolean vipCard) {
        super(jumlahKomputer, namaWarnet, hargaPerJam);
        this.vipCard = vipCard;
    }

    @Override
    public void informasi() {
        super.informasi();
        System.out.println(" Status           : Member VIP");
        System.out.println("=====================================");
        System.out.println();
        System.out.println("=====================================");
        System.out.println("         Benefit Member VIP          ");
        System.out.println("-------------------------------------");
        System.out.println(" 1. Main 3 jam ++ diskon 10%");
        System.out.println(" 2. Main 4 jam gratis Minum enak");
        System.out.println(" 3. Prioritas booking komputer gaming");
        System.out.println("=====================================");
        System.out.println();
    }
    
    public void login(String username) {
        System.out.println("=====================================");
        System.out.println("           Informasi Lainya          ");
        System.out.println("-------------------------------------");
        System.out.println("Login dengan username: " + username);
    }
    public void bermain(int jam) {
        System.out.println("Bermain selama " + jam + " jam");
    }
    public void bermain(int jam, int menitTambahan) {
        System.out.println("Bermain selama " + jam + " jam " + menitTambahan + " menit");
        System.out.println();
        System.out.println();
    }
}
