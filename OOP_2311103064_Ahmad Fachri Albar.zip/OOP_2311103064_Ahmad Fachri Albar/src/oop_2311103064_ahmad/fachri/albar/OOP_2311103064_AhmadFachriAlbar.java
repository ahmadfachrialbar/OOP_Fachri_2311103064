/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oop_2311103064_ahmad.fachri.albar;

/**
 *
 * @author Ahmad Fachri Albar_2311103064_SI07B
 */
public class OOP_2311103064_AhmadFachriAlbar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    KomputerVIP vip = new KomputerVIP(15, "Warnet Gacor", 10000.0f, true);
    
        vip.informasi();
        vip.login("Fachri");
        vip.bermain(5);
        vip.bermain(5, 2);

        KomputerPremium premium = new KomputerPremium(5, "Warnet Asoy", 20000.0f, true);
        premium.informasi();
        premium.pesan(5);
        premium.tambahLayanan("Nasi Goreng");
        premium.tambahLayanan("Seblak", "Anggur enak");
    }
}