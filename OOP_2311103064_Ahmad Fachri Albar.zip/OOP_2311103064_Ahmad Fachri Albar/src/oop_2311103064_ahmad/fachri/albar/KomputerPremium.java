/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop_2311103064_ahmad.fachri.albar;

/**
 *
 * @author Ahmad Fachri Albar_2311103064_SI07B
 */
public class KomputerPremium extends Komputer {
    protected boolean ruangPrivat;
    public KomputerPremium(int jumlahKomputer, String namaWarnet, float hargaPerJam, boolean ruangPrivat) {
        super(jumlahKomputer, namaWarnet, hargaPerJam);
        this.ruangPrivat = ruangPrivat;
    }
    
    @Override
    public void informasi() {
        super.informasi();
        System.out.println("Status            : Ruangan Premium");
        System.out.println("=====================================");
        System.out.println();
        System.out.println("=====================================");
        System.out.println("        Benefit Ruang Premium        ");
        System.out.println("-------------------------------------");
        System.out.println(" 1. Setiap ruang ber AC");
        System.out.println(" 2. Sofa gaming Empuk");
        System.out.println(" 3, Komputer spek gacor");
        System.out.println(" 4. Koneksi internet kenceng 100Mbps");
        System.out.println("=====================================");
        System.out.println();
    }

    public void pesan(int nomorKomputer) {
        System.out.println("=====================================");
        System.out.println("          Informasi Lainya           ");
        System.out.println("-------------------------------------");
        System.out.println("Memesan komputer nomor: " + nomorKomputer);
    }

    public void tambahLayanan(String makanan) {
        System.out.println("Memesan makanan : " + makanan);
    }

    public void tambahLayanan(String makanan, String minuman) {
        System.out.println("Memesan Makanan : " + makanan);
        System.out.println("Memesan minuman : " + minuman);
        System.out.println("=====================================");
    }
}

